import React from 'react';

function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <p>&copy; 2025 Vision International. All rights reserved.</p>
        <p>Email: info@visioninternational.ng | Phone: +234 123 456 7890</p>
      </div>
    </footer>
  );
}

export default Footer;
