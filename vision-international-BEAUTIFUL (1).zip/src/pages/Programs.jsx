import React from 'react';

function Programs() {
  return (
    <div>
      {/* Page Header */}
      <section className="hero">
        <div className="container">
          <h1>Our Programs</h1>
          <p>Creating Lasting Impact Through Six Core Areas</p>
        </div>
      </section>

      {/* Programs List */}
      <section className="section">
        <div className="container">
          
          {/* Education Program */}
          <div className="card">
            <h2>📚 Education for All</h2>
            <p>
              Providing quality education and learning materials to underprivileged children 
              in rural communities across Nigeria.
            </p>
            <h4>What We Do:</h4>
            <ul style={{paddingLeft: '20px', lineHeight: '1.8'}}>
              <li>Provide school supplies and textbooks</li>
              <li>Offer scholarship programs</li>
              <li>After-school tutoring</li>
              <li>Digital literacy training</li>
            </ul>
            <p><strong>Impact:</strong> 5,000+ students helped | 25 schools supported</p>
          </div>

          {/* Healthcare Program */}
          <div className="card">
            <h2>❤️ Healthcare Access</h2>
            <p>
              Delivering essential healthcare services and medical supplies to remote areas 
              with limited access to medical facilities.
            </p>
            <h4>What We Do:</h4>
            <ul style={{paddingLeft: '20px', lineHeight: '1.8'}}>
              <li>Mobile health clinics</li>
              <li>Free medical checkups</li>
              <li>Medicine distribution</li>
              <li>Health education workshops</li>
            </ul>
            <p><strong>Impact:</strong> 3,500+ patients treated | 15 clinics established</p>
          </div>

          {/* Water Program */}
          <div className="card">
            <h2>💧 Clean Water Initiative</h2>
            <p>
              Building sustainable water systems to provide clean, safe drinking water 
              to communities in need.
            </p>
            <h4>What We Do:</h4>
            <ul style={{paddingLeft: '20px', lineHeight: '1.8'}}>
              <li>Borehole construction</li>
              <li>Water purification systems</li>
              <li>Sanitation training</li>
              <li>Well maintenance</li>
            </ul>
            <p><strong>Impact:</strong> 30+ wells built | 20,000+ people served</p>
          </div>

          {/* Women Empowerment */}
          <div className="card">
            <h2>👩 Women Empowerment</h2>
            <p>
              Supporting women through skills training, microfinance, and entrepreneurship 
              programs to achieve economic independence.
            </p>
            <h4>What We Do:</h4>
            <ul style={{paddingLeft: '20px', lineHeight: '1.8'}}>
              <li>Vocational training</li>
              <li>Micro-loans for businesses</li>
              <li>Business mentorship</li>
              <li>Leadership development</li>
            </ul>
            <p><strong>Impact:</strong> 2,000+ women empowered | 500+ businesses started</p>
          </div>

          {/* Food Security */}
          <div className="card">
            <h2>🌾 Food Security</h2>
            <p>
              Fighting hunger through food distribution programs and sustainable agriculture 
              training for communities.
            </p>
            <h4>What We Do:</h4>
            <ul style={{paddingLeft: '20px', lineHeight: '1.8'}}>
              <li>Food distribution</li>
              <li>Farming training</li>
              <li>Seeds and tools provision</li>
              <li>Nutrition education</li>
            </ul>
            <p><strong>Impact:</strong> 50,000+ meals distributed | 1,500+ farmers trained</p>
          </div>

          {/* Youth Development */}
          <div className="card">
            <h2>⭐ Youth Development</h2>
            <p>
              Empowering young people through skills acquisition, mentorship programs, 
              and career guidance.
            </p>
            <h4>What We Do:</h4>
            <ul style={{paddingLeft: '20px', lineHeight: '1.8'}}>
              <li>Skills training programs</li>
              <li>Mentorship programs</li>
              <li>Career counseling</li>
              <li>Leadership camps</li>
            </ul>
            <p><strong>Impact:</strong> 4,000+ youth trained | 200+ mentors engaged</p>
          </div>

        </div>
      </section>
    </div>
  );
}

export default Programs;
