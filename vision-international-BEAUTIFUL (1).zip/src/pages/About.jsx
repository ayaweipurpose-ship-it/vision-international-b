import React from 'react';

function About() {
  return (
    <div>
      {/* Page Header */}
      <section className="hero">
        <div className="container">
          <h1>About Vision International</h1>
          <p>Building Hope Since 2015</p>
        </div>
      </section>

      {/* Content */}
      <section className="section">
        <div className="container">
          <div className="card">
            <h2>Our Story</h2>
            <p>
              Vision International was founded in 2015 with a mission to transform lives 
              and empower communities across Nigeria. What started as a small community 
              project has grown into a nationwide movement impacting over 50,000 lives.
            </p>
          </div>

          <div className="card">
            <h2>Our Mission</h2>
            <p>
              To empower underprivileged communities through comprehensive programs in 
              education, healthcare, clean water access, and economic development, creating 
              sustainable pathways out of poverty.
            </p>
          </div>

          <div className="card">
            <h2>Our Vision</h2>
            <p>
              A Nigeria where every individual has access to quality education, healthcare, 
              clean water, and economic opportunities, regardless of their background or location.
            </p>
          </div>

          <div className="card">
            <h2>Our Values</h2>
            <ul style={{paddingLeft: '20px', lineHeight: '2'}}>
              <li><strong>Compassion:</strong> We care deeply about the people we serve</li>
              <li><strong>Transparency:</strong> We are accountable for every donation</li>
              <li><strong>Sustainability:</strong> We create long-term solutions</li>
              <li><strong>Integrity:</strong> We operate with honesty and ethics</li>
              <li><strong>Collaboration:</strong> We work together for greater impact</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
}

export default About;
