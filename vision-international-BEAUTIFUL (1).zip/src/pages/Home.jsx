import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="hero">
        <div className="container">
          <h1>Building Hope, Creating Change</h1>
          <p>Empowering communities across Nigeria through education, healthcare, and development</p>
          <Link to="/donate" className="btn">Donate Now</Link>
        </div>
      </section>

      {/* Our Impact */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Our Impact</h2>
          
          <div className="grid">
            <div className="card">
              <h3>50,000+</h3>
              <p>Lives Impacted</p>
            </div>
            
            <div className="card">
              <h3>100+</h3>
              <p>Communities Served</p>
            </div>
            
            <div className="card">
              <h3>250+</h3>
              <p>Active Projects</p>
            </div>
          </div>
        </div>
      </section>

      {/* Programs */}
      <section className="section" style={{backgroundColor: 'white'}}>
        <div className="container">
          <h2 className="section-title">Our Programs</h2>
          
          <div className="grid">
            <div className="card">
              <h3>Education</h3>
              <p>Providing quality education and school supplies to underprivileged children.</p>
            </div>
            
            <div className="card">
              <h3>Healthcare</h3>
              <p>Delivering essential healthcare services to remote communities.</p>
            </div>
            
            <div className="card">
              <h3>Clean Water</h3>
              <p>Building sustainable water systems for safe drinking water.</p>
            </div>
            
            <div className="card">
              <h3>Women Empowerment</h3>
              <p>Supporting women through skills training and microfinance.</p>
            </div>
            
            <div className="card">
              <h3>Food Security</h3>
              <p>Fighting hunger through food distribution and agriculture training.</p>
            </div>
            
            <div className="card">
              <h3>Youth Development</h3>
              <p>Empowering young people through skills and mentorship programs.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="section" style={{backgroundColor: '#1a5f3f', color: 'white', textAlign: 'center'}}>
        <div className="container">
          <h2 style={{color: 'white', marginBottom: '20px'}}>Make a Difference Today</h2>
          <p style={{fontSize: '18px', marginBottom: '30px'}}>
            Your donation can transform lives. Join us in building a brighter future.
          </p>
          <Link to="/donate" className="btn btn-secondary">Donate Now</Link>
        </div>
      </section>
    </div>
  );
}

export default Home;
