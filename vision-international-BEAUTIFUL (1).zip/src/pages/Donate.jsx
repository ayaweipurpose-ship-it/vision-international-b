import React, { useState } from 'react';

function Donate() {
  // State to track if user clicked copy button
  const [copied, setCopied] = useState(false);

  // Function to copy account number
  const copyAccountNumber = () => {
    // Copy the account number to clipboard
    navigator.clipboard.writeText('2034567890');
    // Show "Copied!" message
    setCopied(true);
    // Hide message after 2 seconds
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div>
      {/* Page Header */}
      <section className="hero">
        <div className="container">
          <h1>Make a Donation</h1>
          <p>Your generosity transforms lives</p>
        </div>
      </section>

      {/* Donation Instructions */}
      <section className="section">
        <div className="container">
          
          <div className="card">
            <h2>How to Donate</h2>
            <p>
              You can make a donation by transferring directly to our bank account. 
              Please use the details below:
            </p>

            {/* Bank Details Box */}
            <div className="bank-details">
              <div className="bank-detail">
                <strong>Bank Name:</strong>
                <span>First Bank of Nigeria</span>
              </div>

              <div className="bank-detail">
                <strong>Account Name:</strong>
                <span>Vision International Foundation</span>
              </div>

              <div className="bank-detail">
                <strong>Account Number:</strong>
                <span style={{fontSize: '24px', color: '#1a5f3f', fontWeight: 'bold'}}>
                  2034567890
                </span>
                <button 
                  onClick={copyAccountNumber} 
                  className="btn" 
                  style={{marginLeft: '10px'}}
                >
                  {copied ? 'Copied!' : 'Copy Number'}
                </button>
              </div>

              <div className="bank-detail">
                <strong>SWIFT Code (for international transfers):</strong>
                <span>FBNINGLA</span>
              </div>
            </div>

            <div style={{
              backgroundColor: '#fff3cd', 
              padding: '15px', 
              borderLeft: '4px solid #d4915f',
              marginTop: '20px'
            }}>
              <p>
                <strong>⚠️ Important:</strong> After making your donation, please send 
                proof of payment to <strong>donations@visioninternational.ng</strong> with 
                your name and contact details to receive a tax receipt.
              </p>
            </div>
          </div>

          {/* Donation Impact */}
          <div className="card">
            <h2>See Your Impact</h2>
            <p>Here's how your donation can make a difference:</p>
            
            <div style={{marginTop: '20px'}}>
              <div style={{padding: '15px', backgroundColor: '#f9f9f9', marginBottom: '10px', borderRadius: '5px'}}>
                <strong>₦5,000</strong> - Provide school supplies for 5 children
              </div>
              
              <div style={{padding: '15px', backgroundColor: '#f9f9f9', marginBottom: '10px', borderRadius: '5px'}}>
                <strong>₦25,000</strong> - Sponsor a child's education for one term
              </div>
              
              <div style={{padding: '15px', backgroundColor: '#f9f9f9', marginBottom: '10px', borderRadius: '5px'}}>
                <strong>₦50,000</strong> - Support a family with healthcare for 3 months
              </div>
              
              <div style={{padding: '15px', backgroundColor: '#f9f9f9', marginBottom: '10px', borderRadius: '5px'}}>
                <strong>₦100,000</strong> - Build a water well in a rural community
              </div>
              
              <div style={{padding: '15px', backgroundColor: '#f9f9f9', marginBottom: '10px', borderRadius: '5px'}}>
                <strong>₦500,000</strong> - Renovate a classroom in a rural school
              </div>
            </div>
          </div>

          {/* Why Donate */}
          <div className="card">
            <h2>Why Donate to Vision International?</h2>
            
            <div style={{marginTop: '20px'}}>
              <h3>✓ 100% Transparent</h3>
              <p>We provide detailed reports on how every naira is spent.</p>
              
              <h3 style={{marginTop: '20px'}}>✓ Tax Deductible</h3>
              <p>All donations are tax-deductible in Nigeria.</p>
              
              <h3 style={{marginTop: '20px'}}>✓ Direct Impact</h3>
              <p>90% of donations go directly to programs helping communities.</p>
              
              <h3 style={{marginTop: '20px'}}>✓ Proven Track Record</h3>
              <p>Since 2015, we've impacted over 50,000 lives across Nigeria.</p>
            </div>
          </div>

          {/* Contact */}
          <div className="card" style={{textAlign: 'center'}}>
            <h2>Need Help?</h2>
            <p>Have questions about donating? Contact us:</p>
            <p>
              <strong>Email:</strong> donations@visioninternational.ng<br/>
              <strong>Phone:</strong> +234 123 456 7890
            </p>
          </div>

        </div>
      </section>
    </div>
  );
}

export default Donate;
