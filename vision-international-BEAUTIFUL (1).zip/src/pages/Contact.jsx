import React, { useState } from 'react';

function Contact() {
  // State to store form data
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent page reload
    alert('Thank you for contacting us! We will get back to you soon.');
    // Reset form
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
  };

  // Handle input changes
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div>
      {/* Page Header */}
      <section className="hero">
        <div className="container">
          <h1>Contact Us</h1>
          <p>We'd love to hear from you</p>
        </div>
      </section>

      {/* Contact Form and Info */}
      <section className="section">
        <div className="container">
          
          <div style={{display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '30px'}}>
            
            {/* Contact Form */}
            <div className="card">
              <h2>Send Us a Message</h2>
              <form onSubmit={handleSubmit}>
                
                <div className="form-group">
                  <label>Your Name *</label>
                  <input 
                    type="text" 
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required 
                    placeholder="Enter your full name"
                  />
                </div>

                <div className="form-group">
                  <label>Your Email *</label>
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required 
                    placeholder="Enter your email address"
                  />
                </div>

                <div className="form-group">
                  <label>Subject *</label>
                  <input 
                    type="text" 
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required 
                    placeholder="What is this about?"
                  />
                </div>

                <div className="form-group">
                  <label>Message *</label>
                  <textarea 
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required 
                    rows="6"
                    placeholder="Write your message here..."
                  ></textarea>
                </div>

                <button type="submit" className="btn" style={{width: '100%'}}>
                  Send Message
                </button>
              </form>
            </div>

            {/* Contact Information */}
            <div>
              <div className="card">
                <h3>Contact Information</h3>
                
                <div style={{marginTop: '20px'}}>
                  <h4>📍 Address</h4>
                  <p>123 Charity Lane<br/>Lagos, Nigeria</p>
                </div>

                <div style={{marginTop: '20px'}}>
                  <h4>📞 Phone</h4>
                  <p>+234 (0) 123 456 7890</p>
                </div>

                <div style={{marginTop: '20px'}}>
                  <h4>📧 Email</h4>
                  <p>info@visioninternational.ng</p>
                </div>

                <div style={{marginTop: '20px'}}>
                  <h4>🕐 Office Hours</h4>
                  <p>Monday - Friday<br/>9:00 AM - 5:00 PM</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>
    </div>
  );
}

export default Contact;
